# Paper Bot 10.0

Paper trading only: **no real trades, no API keys**, 1000 virtual EUR starting balance.

Uses public Kraken 4-hour closed OHLC data for BTC/ETH/SOL EUR. SMA20/50 crossover entry and exit; position cap 20% of equity, simulated 0.1% fees, 6% close-based stop, 10% maximum drawdown halt, 3-bar cooldown. Simulation is illustrative and does not predict profitable trading. A 4h closing-price stop cannot guarantee a 6% maximum realized loss.

## Start on GitHub from your phone

1. Open your GitHub repository **Bot_10** and upload `bot.py`, `state.json`, and `.github/workflows/paper-bot.yml` to the corresponding paths. GitHub's mobile browser may require *Desktop site* for folders; the workflow must live in `.github/workflows/`.
2. Go to **Actions**, allow Actions if prompted.
3. Choose **Paper Bot 10.0** > **Run workflow** (branch `main`).
4. Check the run log and `state.json` to see virtual balance and actions.

The schedule attempts a run every 4 hours, but GitHub Actions is not an always-on server and runs may be delayed. Workflow commits back to state.json; repository Actions settings may need workflow read/write permissions. **Never upload private API credentials to a public repository.**
